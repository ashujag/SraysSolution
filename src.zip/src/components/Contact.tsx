import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageSquare } from 'lucide-react';
import bgImage from '../assets/6847119f22b5391772dbf625_684efaff0f6e64c09d96d807_freepik__animate-this-with-8k-loop__54302-poster-00001.jpg';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    contact: '',
    email: '',
    company: '',
    subject: '',
    message: '',
    subscriberEmail: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'Anton, sans-serif' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sacramento&family=Anton&display=swap');
        .sacramento-font {
          font-family: 'Sacramento', cursive;
        }
        .anton-font {
          font-family: 'Anton', sans-serif;
        }
      `}</style>

      {/* Hero Section */}
      <div
        className="relative h-96 bg-black overflow-hidden flex items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: `url(${bgImage})` }}
      >
        <div className="absolute inset-0 opacity-20 bg-black"></div>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-teal-500 rounded-full filter blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-teal-400 rounded-full filter blur-3xl"></div>
        </div>
        <div className="relative text-center z-10">
          <h1 className="sacramento-font text-7xl font-bold text-lime-300 italic">
            Contact
          </h1>
          <p className="anton-font text-5xl font-bold text-white mt-2">LETS TALK</p>
        </div>
      </div>

      {/* Contact Form Section */}
      <div className="bg-white px-8 py-16">
        {/* Yellow Banner */}
        <div className="bg-yellow-300 rounded-lg p-4 mb-12 flex justify-center gap-8 text-sm font-bold text-black anton-font">
          <div className="flex items-center gap-2">
            <span>●</span>
            <span>Quick response within 24/7</span>
          </div>
          <div className="flex items-center gap-2">
            <span>●</span>
            <span>Clear project updates</span>
          </div>
          <div className="flex items-center gap-2">
            <span>●</span>
            <span>Available across time zones</span>
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div>
            {/* Name Row */}
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">First name</label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">Last name</label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
            </div>

            {/* Contact Row */}
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">CONTACT</label>
                <input
                  type="text"
                  name="contact"
                  value={formData.contact}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">EMAIL</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
            </div>

            {/* Company Row */}
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">COMPANY</label>
                <input
                  type="text"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
              <div>
                <label className="text-sm font-bold text-black mb-2 block anton-font">SUBJECT</label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="w-full border-2 border-gray-300 p-3 rounded anton-font"
                />
              </div>
            </div>

            {/* Message */}
            <div className="mb-8">
              <label className="text-sm font-bold text-black mb-2 block anton-font">MESSAGE</label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                className="w-full border-2 border-gray-300 p-3 rounded h-40 resize-none anton-font"
              ></textarea>
            </div>

            {/* Submit Button */}
            <div className="mb-16">
              <button
                onClick={handleSubmit}
                className="bg-lime-400 text-black font-bold px-8 py-3 rounded-full hover:bg-lime-500 transition anton-font"
              >
                SUBMIT NOW
              </button>
            </div>
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-3 gap-8 mb-16">
            <div className="flex items-center gap-4">
              <div className="bg-yellow-300 rounded-full p-3">
                <Phone className="w-6 h-6 text-black" />
              </div>
              <div>
                <p className="font-bold text-black anton-font">PHONE</p>
                <p className="text-sm text-gray-600 anton-font">+117 2345 6948</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-yellow-300 rounded-full p-3">
                <Mail className="w-6 h-6 text-black" />
              </div>
              <div>
                <p className="font-bold text-black anton-font">MAIL</p>
                <p className="text-sm text-gray-600 anton-font">@clickboom@-mail</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-yellow-300 rounded-full p-3">
                <MapPin className="w-6 h-6 text-black" />
              </div>
              <div>
                <p className="font-bold text-black anton-font">ADDRESS</p>
                <p className="text-sm text-gray-600 anton-font">New York, USA</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <div className="bg-white border-t border-gray-200 px-8 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-4 gap-12 mb-16">
            {/* Left Column */}
            <div>
              <p className="text-xs font-bold text-gray-600 mb-2 anton-font">SOURCE</p>
              <p className="text-xs text-gray-600 mb-4 anton-font">THINKING YOUR DREAMS WITH HUM IDEAS</p>
              <p className="text-xs font-bold text-black anton-font">© CLICK</p>
            </div>

            {/* Company Column */}
            <div>
              <p className="text-xs font-bold text-black mb-4 anton-font">COMPANY</p>
              <div className="space-y-2">
                <p className="text-xs text-gray-600 anton-font">HOME</p>
                <p className="text-xs text-gray-600 anton-font">ABOUT US</p>
                <p className="text-xs text-gray-600 anton-font">BLOG</p>
              </div>
            </div>

            {/* Other Pages Column */}
            <div>
              <p className="text-xs font-bold text-black mb-4 anton-font">OTHER PAGES</p>
              <div className="space-y-2">
                <p className="text-xs text-gray-600 anton-font">PROJECTS</p>
                <p className="text-xs text-gray-600 anton-font">CAREER</p>
                <p className="text-xs text-gray-600 anton-font">CONTACT US</p>
                <p className="text-xs text-gray-600 anton-font">LICENSE</p>
              </div>
            </div>

            {/* Right Column */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-amber-900"></div>
                <div>
                  <p className="text-xs font-bold text-black anton-font">RICH JOHNSON</p>
                  <p className="text-xs font-bold text-orange-500 anton-font">LEAD DESIGNER & DIRECTION</p>
                </div>
              </div>
              <p className="text-xs font-bold text-black anton-font">LETS WORK TOGETHER.</p>
            </div>
          </div>

          {/* CTA Button */}
          <div className="bg-lime-400 rounded-full py-6 px-8 text-center mb-16 flex items-center justify-center gap-2">
            <MessageSquare className="w-6 h-6 text-black" />
            <p className="text-2xl font-bold text-black anton-font">LET'S TALK</p>
          </div>

          {/* Newsletter */}
          <div className="grid grid-cols-2 gap-12 border-t border-gray-200 pt-8">
            <div>
              <p className="text-xs font-bold text-black mb-2 anton-font">SUBSCRIBE TO OUR NEWSLETTER</p>
              <p className="text-xs text-gray-600 mb-4 anton-font">Subscribe to our exclusive news updates!</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="ENTER YOUR EMAIL"
                  value={formData.subscriberEmail}
                  onChange={(e) => setFormData(prev => ({ ...prev, subscriberEmail: e.target.value }))}
                  className="flex-1 border-b-2 border-black bg-white px-2 py-1 text-xs outline-none anton-font"
                />
                <button className="text-black font-bold text-xs anton-font">↑</button>
              </div>
            </div>
            <div className="flex justify-end items-end">
              <p className="text-xs text-gray-600 text-right anton-font">
                CLICK TO GO UP ↑<br />
                <span className="text-black font-bold">COPYRIGHT 2025 - © CLICKBOOM - POWERED BY NORFORK</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}