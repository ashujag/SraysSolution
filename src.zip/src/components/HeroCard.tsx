import Hero from './Hero';

function HeroCard() {
  return (
    <div className="min-h-screen">
      <Hero />
    </div>
  );
}

export default HeroCard;
