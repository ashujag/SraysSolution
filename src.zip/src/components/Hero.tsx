import React, { useEffect, useRef, useState } from 'react';
import { Menu } from 'lucide-react';
import logoheader from '../assets/logoheader.png'; // Import the logo image
import heroBackgroundImage from '../assets/6847119f22b5391772dbf625_684efaff0f6e64c09d96d807_freepik__animate-this-with-8k-loop__54302-poster-00001.jpg';

// Add Google Fonts
const fontLink = document.createElement('link');
fontLink.href = 'https://fonts.googleapis.com/css2?family=Sacramento&family=Anton&display=swap';
fontLink.rel = 'stylesheet';
document.head.appendChild(fontLink);

const HeroSection: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const welcomeRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const sectionTwoRef = useRef<HTMLDivElement>(null);
  const section2TextRef = useRef<HTMLDivElement>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [rotatingTextIndex, setRotatingTextIndex] = useState(0);
  const rotatingTexts = ['HR Solutions', 'IT Services', 'Designing'];

  const menuItems = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'Contact', href: '#contact' },
    { label: 'Blog', href: '#blog' }
  ];

  useEffect(() => {
    // Hero section animations
    const timeline = [
      { element: bgRef.current, delay: 0 },
      { element: welcomeRef.current, delay: 300 },
      { element: subtitleRef.current, delay: 500 },
      { element: titleRef.current, delay: 700 },
      { element: ctaRef.current, delay: 1000 }
    ];

    timeline.forEach(({ element, delay }) => {
      if (element) {
        setTimeout(() => {
          element.style.opacity = '1';
          element.style.transform = 'translateY(0)';
        }, delay);
      }
    });

    // Section 2 scroll animation
    const observerOptions = {
      threshold: 0.2,
      rootMargin: '0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          if (section2TextRef.current) {
            section2TextRef.current.style.opacity = '1';
            section2TextRef.current.style.transform = 'translateY(0)';
          }
        }
      });
    }, observerOptions);

    if (sectionTwoRef.current) {
      observer.observe(sectionTwoRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const rotatingInterval = setInterval(() => {
      setRotatingTextIndex((prev) => (prev + 1) % rotatingTexts.length);
    }, 2000);
    
    return () => clearInterval(rotatingInterval);
  }, [rotatingTexts.length]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isMenuOpen]);

  return (
    <div className="w-full bg-black">
      {/* Hero Section */}
      <div ref={heroRef} className="relative w-full h-screen bg-black overflow-hidden">
        {/* Video Background */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            backgroundImage: `url('${heroBackgroundImage}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <source 
            src="https://cdn.prod.website-files.com/6847119f22b5391772dbf625%2F684efaff0f6e64c09d96d807_freepik__animate-this-with-8k-loop__54302-transcode.mp4" 
            type="video/mp4" 
          />
          <source 
            src="https://cdn.prod.website-files.com/6847119f22b5391772dbf625%2F684efaff0f6e64c09d96d807_freepik__animate-this-with-8k-loop__54302-transcode.webm" 
            type="video/webm" 
          />
        </video>

        {/* Animated Overlay */}
        <div
          ref={bgRef}
          className="absolute inset-0 transition-all duration-1000 ease-out"
          style={{ 
            opacity: 0,
            background: 'radial-gradient(ellipse at 50% 60%, rgba(16, 185, 129, 0.3) 0%, rgba(6, 78, 59, 0.2) 30%, rgba(0, 0, 0, 0.6) 70%)',
          }}
        >
          <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-3xl" style={{ animationDelay: '1s' }}></div>
        </div>

        {/* Yellow circle decoration */}
        <div className="absolute bottom-32 right-40 w-16 h-16 bg-lime-400 rounded-full z-10 animate-bounce" style={{ animationDuration: '3s' }}></div>

        {/* Navigation */}
        <nav className="relative z-20 flex items-center justify-between px-8 py-6 text-white">
          <div className="flex items-center">
            <img src={logoheader} alt="GREEKON Logo" className="h-10" /> {/* Adjust height as needed */}
          </div>
          
          <div className="flex items-center gap-8 text-sm">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-lime-400 rounded-full"></span>
              <span>TORONTO, CANADA</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-lime-400 rounded-full"></span>
              <span>HELLO@srayssolutions.com</span>
            </div>
          </div>

          {/* Bubble Menu */}
          <div ref={menuRef} className="relative">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="w-12 h-12 bg-lime-400 text-black rounded-full flex items-center justify-center hover:bg-lime-300 transition-all duration-300 hover:scale-110"
            >
              <Menu size={24} />
            </button>

            {/* Menu Dropdown */}
            {isMenuOpen && (
              <div className="absolute top-16 right-0 bg-black/95 backdrop-blur-md rounded-3xl p-6 min-w-max border border-lime-400/30 shadow-2xl z-50">
                <div className="grid grid-cols-2 gap-4">
                  {menuItems.map((item, index) => (
                    <a
                      key={index}
                      href={item.href}
                      className="px-4 py-2 text-white hover:text-lime-400 transition-colors duration-200 text-sm uppercase tracking-wider hover:bg-lime-400/10 rounded-lg"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </nav>

        {/* Hero Content */}
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-white px-8 -mt-20">
          <div
            ref={welcomeRef}
            className="text-left w-full max-w-6xl mb-8 transition-all duration-700 ease-out"
            style={{ opacity: 0, transform: 'translateY(20px)' }}
          >
            {/* <div className="text-sm uppercase tracking-wider">
              <div>- WELCOME TO</div>
              <div className="mt-1">GREEKON, WHERE</div>
              <div className="mt-1">TOO CREATIVITY.</div>
            </div> */}
          </div>

          <div className="text-center max-w-5xl">
            <div
              ref={subtitleRef}
              className="text-4xl md:text-5xl lg:text-6xl font-light mb-6 transition-all duration-700 ease-out"
              style={{ 
                opacity: 0, 
                transform: 'translateY(30px)',
                fontFamily: 'Sacramento, cursive'
              }}
            >
              <span className="text-lime-300">
                Design an optimal business model to reach Your{' '}
                <span 
                  className="inline-block transition-all duration-500 ease-in-out"
                  key={rotatingTextIndex}
                  style={{
                    animation: 'fadeSlideIn 0.5s ease-in-out'
                  }}
                >
                  {rotatingTexts[rotatingTextIndex]}
                </span>
              </span>
            </div>
            
            <h1
              ref={titleRef}
              className="text-4xl md:text-6xl lg:text-7xl font-black uppercase leading-tight mb-8 transition-all duration-1000 ease-out"
              style={{ 
                opacity: 0, 
                transform: 'translateY(40px)',
                letterSpacing: '-0.02em',
                fontFamily: 'Anton, sans-serif'
              }}
            >
              The process of business model construction and modification is also called business model innovation.
            </h1>

            <button
              ref={ctaRef}
              className="bg-lime-400 text-black px-12 py-4 rounded-full text-lg font-bold uppercase hover:bg-lime-300 transition-all duration-300 hover:scale-105"
              style={{ 
                opacity: 0, 
                transform: 'translateY(20px)',
                fontFamily: 'Anton, sans-serif'
              }}
            >
              Learn More
            </button>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32">
          <svg viewBox="0 0 1200 100" className="w-full h-full" preserveAspectRatio="none">
            <path d="M0,50 Q300,80 600,50 T1200,50 L1200,100 L0,100 Z" fill="rgba(16, 185, 129, 0.1)" />
          </svg>
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        @keyframes fadeSlideIn {
          0% {
            opacity: 0;
            transform: translateY(-10px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-scroll {
          animation: scroll 30s linear infinite;
        }

        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};

export default HeroSection;
