import { useState } from "react";
import { Play, X } from "lucide-react";

interface KnowledgeItem {
  id: number;
  title: string;
  author: string;
  description: string;
  thumbnail: string;
  videoId: string;
  type: string;
}

const KnowledgeSpot = () => {
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);

  const knowledgeItems: KnowledgeItem[] = [
    {
      id: 1,
      title: "HR skills training program",
      author: "By SRays",
      description:
        "Happy to associate with K. S. R. Educational institutions for HR skills training program...",
      thumbnail: "https://i.ytimg.com/vi/zqR8bw8bqdM/maxresdefault.jpg",
      videoId: "zqR8bw8bqdM",
      type: "video",
    },
    {
      id: 2,
      title: "A business plan is a formal written document business...",
      author: "By SRays",
      description:
        "A business plan is a formal written document containing business goals. The methods on...",
      thumbnail: "https://i.ytimg.com/vi/7s-uYaQcqq4/hqdefault.jpg",
      videoId: "7s-uYaQcqq4",
      type: "video",
    },
    {
      id: 3,
      title: "A business is the activity of making one's living",
      author: "By SRays",
      description:
        "Business may offer to many opportunities such as the activity of buying and...",
      thumbnail: "https://i.ytimg.com/vi/7CenIv7jl_k/sddefault.jpg",
      videoId: "7CenIv7jl_k",
      type: "video",
    },
  ];

  const toggleVideo = (videoId: string) => {
    setSelectedVideoId((prev) => (prev === videoId ? null : videoId));
  };

  return (
    <div id="knowledge-spot" className="bg-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">
            Knowledge Spot
          </h2>
          <p className="text-gray-500 text-sm mb-2">demo</p>
          <p className="text-gray-600 max-w-3xl">
            News websites and blogs are common sources for web feeds, but feeds
            are also used to deliver structured
          </p>
        </div>

        {/* Knowledge Cards Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {knowledgeItems.map((item) => (
            <div
              key={item.id}
              className="group cursor-pointer"
              onClick={() => toggleVideo(item.videoId)}
            >
              <div className="relative overflow-hidden rounded-lg mb-4 aspect-video">
                {selectedVideoId === item.videoId ? (
                  <div className="relative w-full h-full">
                    {/* Close Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent card click
                        setSelectedVideoId(null);
                      }}
                      className="absolute top-2 right-2 bg-black/60 hover:bg-black text-white rounded-full p-1 transition"
                    >
                      <X size={20} />
                    </button>

                    {/* Embedded Video */}
                    <iframe
                      className="absolute inset-0 w-full h-full rounded-lg"
                      src={`https://www.youtube.com/embed/${item.videoId}?autoplay=1`}
                      title={item.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                ) : (
                  <>
                    <img
                      src={item.thumbnail}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-all duration-300"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-white transition-all duration-300 group-hover:scale-110">
                        <Play
                          className="text-gray-900 ml-1"
                          size={28}
                          fill="currentColor"
                        />
                      </div>
                    </div>
                    <div className="absolute bottom-3 right-3 bg-black/80 text-white text-xs px-2 py-1 rounded">
                      Video
                    </div>
                  </>
                )}
              </div>

              {/* Card Content */}
              <div className="space-y-2">
                <p className="text-sm text-gray-500">{item.author}</p>
                <h3 className="text-xl font-bold text-gray-900 group-hover:text-cyan-600 transition-colors line-clamp-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 text-sm line-clamp-2">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default KnowledgeSpot;
